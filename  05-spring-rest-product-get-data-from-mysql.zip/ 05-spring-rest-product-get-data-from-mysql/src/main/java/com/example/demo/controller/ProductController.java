package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.service.IProductService;
import com.example.demo.service.ProductService;

@RestController
	public class ProductController {
		@Autowired
		IProductService productService ;
	
	    @GetMapping("/")
	    String productMessage() {
	        return "List of Product added!";
	    }
	    //@GetMapping(path = "/products", produces = {MediaType.APPLICATION_XML_VALUE})
	    @GetMapping(path = "/products", produces = {MediaType.APPLICATION_JSON_VALUE})
	    List<Product> products() {
	        return productService.findAllProducts();
	    }
	    
	    //Demo of @PathVariable
	    @GetMapping("/products/{id}")
	    Product findByProductId(@PathVariable int id)
	    {return productService.getProduct(id);}
	    
	    
	    @GetMapping("/product") 
	    //http://localhost:9090/product
	    //http://localhost:9090/product?id=101
		public Product getProduct(@RequestParam(defaultValue = "100") int id) {
			return  productService.getProduct(id);
	    }
	    
	    
	    
	    //Demo of @PathVariable http://localhost:9090/products/db
	    @GetMapping("/products/db")
	    List<Product>findAllByProductsFromDB()
	    {
	    	System.out.println(productService.getAllProductsFromDatabase());
	    	return productService.getAllProductsFromDatabase();
	    }
	    
	    //Demo of @PathVariable
	    @GetMapping("/products/db/{id}")
	    Optional<Product>   findByProductIdFromDB(@PathVariable int id)
	    {return productService.getProductsFromDatabase(id);}
	    }





